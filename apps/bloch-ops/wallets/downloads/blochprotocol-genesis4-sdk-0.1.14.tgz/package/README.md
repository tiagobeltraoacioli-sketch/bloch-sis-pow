# Genesis-4 JavaScript SDK for exchange integration

This package creates or restores a Genesis-4 mainnet address locally and builds a complete signed Genesis-4 mainnet transfer using the
same pinned WebAssembly signer shipped with the Postern wallet. The caller does
not select UTXOs, calculate fees, encode a transaction, or sign it. The package
has no runtime npm dependencies and requires Node.js 20 or newer.

The source files `g4.cjs` and `bloch_wallet_wasm.wasm` are copied from the
Genesis-4 Postern wallet. The WASM SHA-256 is pinned in `core.mjs`:
`2f6548cd822d4840e4584b0200467fcb352aaf84a70ea2b3be0e3f099bfa5f49`.
This is a source-distributed package; no npm publication is assumed.

This checkout is the **unpublished 0.1.14 release candidate**. It fixes receipt
output-index bounds and persisted-envelope identity. The 0.1.13 artifact is
preserved and does not contain these fixes. Local verification does not prove
P2B adoption, qualification or deployment.

HTTP reads have a 15-second deadline and a 2 MiB response limit. Redirects
are rejected. The SDK validates JSON-RPC version, request ID and result/error
shape before using node data. HTTP and RPC errors expose status or numeric
error code without copying server-supplied body text into logs or unresolved
observations. An archival HTTP 404 still triggers the documented unresolved
transaction lookup; other archival errors remain failures. Transport errors
during `sendrawtransaction` are ambiguous: check the original txid before
submitting any other bytes.

## Install

Install the candidate from its reviewed local tarball after comparing its
SHA-256 with the accompanying release record:

```sh
npm install --offline --ignore-scripts /path/to/blochprotocol-genesis4-sdk-0.1.14.tgz
```

It can also be installed from a local checkout:

```sh
npm install /path/to/bloch-sis-pow/sdk/genesis4-js
```

The previous distribution URL is
`https://ops-blochinc.xyz/wallets/downloads/blochprotocol-genesis4-sdk-0.1.13.tgz`.
Do not assume that changing this URL to `0.1.14` identifies a published release.
Publication and the integrator's installed version require separate evidence.

## Create or restore a local wallet

`createLocalWallet()` uses the pinned wallet core to generate a fresh 24-word
mnemonic and its checksummed Genesis-4 mainnet address. `deriveLocalAddress()`
recovers the address from a phrase you already control. Both run inside the
calling Node.js process and make **no RPC or HTTP request**.

```js
import { createLocalWallet, deriveLocalAddress } from '@blochprotocol/genesis4-sdk';

const wallet = createLocalWallet();
// Back up wallet.mnemonic through your own secure, offline key ceremony.
// Do not print it in logs or send it to an API.
console.log(wallet.address);

const restored = deriveLocalAddress({ mnemonic: wallet.mnemonic });
if (restored.address !== wallet.address) throw new Error('Address mismatch');
```

The SDK returns the mnemonic to the caller once and does not persist or encrypt
it. The caller is responsible for controlled backup, process isolation and key
custody. For an interactive encrypted wallet, use Postern Wallet instead of
placing secrets in a website or a remote Ops endpoint. Importing an older
wallet may require its original derivation convention; the function above uses
the current core's default convention.

## Sign and submit

`amount` is a decimal **string in BLOCH**, with at most eight decimal places.
Never pass a JavaScript floating-point number. The returned `rawHex` is the
complete signed, serialized transaction accepted as the sole parameter of
`sendrawtransaction`. The `txid` is the consensus transaction ID derived by
the signer. It is different from the node's `tx_hash` correlation value.

```js
import { createSignedTransaction, broadcastSignedTransaction } from '@blochprotocol/genesis4-sdk';

const signed = await createSignedTransaction({
  addressFrom: process.env.BLOCH_ADDRESS_FROM,
  mnemonic: process.env.BLOCH_MNEMONIC,
  addressTo: process.env.BLOCH_ADDRESS_TO,
  amount: '1.25000000',
  rpcUrl: process.env.BLOCH_RPC_URL ?? 'https://posternlabs.com/g4rpc',
});

// Store the complete signed object before a network write. The RPC call is
// equivalent to sendrawtransaction([signed.rawHex]).
const submitted = await broadcastSignedTransaction(signed, {
  rpcUrl: process.env.BLOCH_RPC_URL ?? 'https://posternlabs.com/g4rpc',
});
console.log({ txid: signed.txid, admitted: submitted.admission.accepted });
```

Run the included script with `BLOCH_MNEMONIC` and `BLOCH_RPC_URL` set:

```sh
node examples/sign-and-broadcast.mjs "$BLOCH_ADDRESS_FROM" "$BLOCH_ADDRESS_TO" 1.25
```

It prints signed bytes without broadcasting by default. Set
`BLOCH_BROADCAST=1` to submit them. Use an exchange-controlled Genesis-4 RPC
node for custody operations. Keep the mnemonic out of command-line arguments,
logs, and network requests; this SDK sends only script hashes and signed bytes.

The SDK reads `getutxos` and `getchaininfo`, takes the **next** base fee and
current epoch, invokes the core for UTXO selection and fee calculation, checks
the preview against the signed transaction, and enforces block and RPC size
limits. It requests the node's maximum 1,000 UTXOs and returns
`utxosTruncated: true` if the source owns more than the node can enumerate.
The core can still select from the visible coins; if those cannot cover the
amount, an exchange node or indexer with a complete UTXO view is required.
SDK 0.1.13 also has an explicit `utxoMode: 'cursor'` for a node built with the
source-only Genesis-4 cursor extension. **That extension is not deployed on
current mainnet.** The default remains `legacy` and makes the same two-argument
request as earlier versions. Do not enable cursor mode against an unverified
node: the SDK rejects a legacy reply before signing.

```js
const signed = await createSignedTransaction({
  addressFrom, mnemonic, addressTo, amount: '1.25',
  rpcUrl: process.env.BLOCH_RPC_URL,
  utxoMode: 'cursor',
  maxUtxoPages: 10,
});
console.log(signed.utxoPageCount, signed.utxoSourceHead);
```

Cursor mode checks the reported head, slot, total, output order and script hash
across all pages, then requires a matching `getchaininfo` head before signing.
It rejects stale or incomplete enumeration. `maxUtxoPages` is 1–20 (default
10), so addresses exceeding the configured bound fail rather than signing from
a partial list. This is an operator-supplied node observation, not independent
proof of the eUTXO set or finality. Confirm node support and the exact release
before use in a value-bearing workflow.
Transaction creation and broadcast are separate because a transfer's
fee can become stale at the next block; do not rebuild a transfer after a
timeout until the original txid has been checked.

`accepted: true` means mempool admission, not block inclusion or finality.
Persist the exact signed bytes, txid, `signingRootHex` and `rawHash` for
reconciliation and safe transport retries. SDK 0.1.13 requires all four fields
when broadcasting: before network I/O it recomputes the domain-separated txid
from `signingRootHex` and SHA3-256 of `rawHex`; after admission it compares the
node's byte count and `tx_hash` correlation handle. The latter is **not** the
consensus txid. A mismatch after submission is ambiguous because the node may
already have accepted the bytes; check the original txid before retrying.
The 0.1.14 candidate additionally decodes transfer tags `0x01` and `0x06`
and recomputes the spend root from their actual input outpoints, outputs,
declared byte count and tip before broadcast or tracking. Truncated fields,
impossible counts, invalid witness indexes, unsupported tags and trailing bytes
are refused. Each identity field is captured once before validation, so caller
mutation during network I/O cannot change the submitted bytes or returned txid.
This is a bounded structural and identity check, not verification of hybrid
signatures, witness-table ordering, UTXO ownership, fees, activation or consensus
acceptance. Witness bytes are outside the spend root by protocol design; their
correlation hash binds the stored bytes without authenticating their signer.
The raw transaction limit is 524,254 bytes; its encoded JSON-RPC request fits
the node's 1 MiB body cap. Oversized envelopes are refused before byte decoding
or a network callback. Broadcast sends one request and has no automatic retry.
The SDK does not persist signed envelopes or implement an outbox. Callers must
save the exact bytes durably and reconcile an ambiguous result before retrying.
If submission times out, retry the same bytes or look up the txid; do not infer failure from
the timeout.

`trackSignedTransaction(signed, {previousObservation})` checks the stored
signed envelope before reading its txid from the archival API. If no included
receipt exists, it returns an unresolved single-node observation. With a prior
observation, it also reports a changed block, receipt, finality or head through
`comparison`. It never broadcasts, rebuilds or approves a transaction:

```js
import { trackSignedTransaction } from '@blochprotocol/genesis4-sdk';

const tracked = await trackSignedTransaction(signed, {
  previousObservation: previous?.observation ?? null,
});
console.log(tracked.txid, tracked.observation.kind, tracked.comparison.status);
// Save the observation for the next check; apply your own payout policy.
```

For a previously saved signed JSON object, the included read-only CLI prints
only the txid, current observation and comparison; it does not print the
signed bytes or submit a transaction:

```sh
node examples/track-signed.mjs signed.json > first-observation.json
node examples/track-signed.mjs signed.json first-observation.json > next-observation.json
```

The CLI accepts only nonempty regular JSON files of at most 2 MiB. It checks
the saved SDK identity fields and requires a previous tracking result for the
same txid. Optional `BLOCH_RPC_URL` and `BLOCH_EXPLORER_URL` overrides must use
HTTPS without embedded credentials, query or fragment. Its output excludes signed bytes and
mnemonics; an input or network failure produces a fixed diagnostic on stderr.

## Transaction lookup

`getTransaction(txid)` returns one exchange-facing object. It calls the
published `GET https://blochl1.com/api/v1/transactions/{txid}` method, which
joins the canonical archival receipt with a fresh corroborated chain head.

```js
import { getTransaction } from '@blochprotocol/genesis4-sdk';

const tx = await getTransaction(
  '2a70f41229d8587f060c308279238662c2aa331f4d9f32a660231716f418c672'
);
console.log({
  inputs: tx.inputs,
  outputs: tx.outputs,
  feeSat: tx.feeSat,
  height: tx.height,
  slot: tx.slot,
  confirmations: tx.confirmations,
  status: tx.status,
  finalized: tx.finalized,
});
```

Run the example against current Genesis-4 mainnet:

```sh
node examples/lookup.mjs 2a70f41229d8587f060c308279238662c2aa331f4d9f32a660231716f418c672
```

Every input and output carries `value_sat` as a decimal string and a
`script_hash`. Other fields include `blockId`, `transactionIndex`, `kind`,
`sizeBytes`, `stakeSat`, `finalizedHeight`, `observedHeadHeight`,
`observedHeadSlot`, `source`, and `verification`. Confirmations are inclusive:
`observedHeadHeight - height + 1`. `finalized` is true only when the fresh,
corroborated finalized height reaches the canonical receipt's height.
The SDK rejects missing or duplicate outpoints, malformed integer amounts or
script hashes, output txids that differ from the queried transaction, and
contradictory height, confirmation or finality fields. These structural checks
do not independently replay consensus or establish source authenticity.

The archival index currently serves **included transactions**. A 404 does
not prove that a recently submitted transaction failed: it may still be
pending or not yet indexed. No deposit should be credited from a mempool
admission result. Pause crediting when the index or corroborated chain head is
unavailable, and persist the block ID so reorgs can be detected on refresh.

`getTransactionObservation(txid)` wraps that boundary for withdrawal tracking.
It returns `{kind: 'included', receipt}` when the complete canonical receipt is
available. Only after an archival 404, it asks one node for `gettxstatus` and
returns `{kind: 'unresolved', nodeStatus}`. The node status can be `pending`,
`included`, `justified`, `finalized` or `unknown`; none supplies the amounts,
block identity and corroborated finality needed for deposit credit. A failed
node query returns `nodeStatus: null` and remains unresolved. Malformed
included receipts and other archival errors are raised rather than hidden.

```js
import { getTransactionObservation } from '@blochprotocol/genesis4-sdk';

const observation = await getTransactionObservation(process.argv[2]);
if (observation.kind === 'included') {
  console.log(observation.receipt);
} else {
  console.log({ status: 'unresolved', nodeStatus: observation.nodeStatus });
}
```

Run `node examples/observe.mjs <txid>` to try this flow. A node's `unknown`
answer does not prove that a transaction never existed; its status index is
bounded, and a public gateway is not an independent settlement authority.

## Compare successive observations

Persist each observation with the exchange's own transaction record. The pure
`compareTransactionObservations(previous, current)` helper highlights a missing
receipt, changed inclusion block, changed transaction contents, reported
finality height or corroboration regression, or lower observed head height,
slot or confirmation count. Transaction contents include its input/output
outpoints and amounts, fee, stake, index, kind and serialized size. The helper
requires structurally complete included receipts before reporting consistency.
It never
authorizes a deposit credit or withdrawal payout. Differences demand review of
the source records and independent node/checkpoint evidence.

```js
import { getTransactionObservation, compareTransactionObservations } from '@blochprotocol/genesis4-sdk';

const current = await getTransactionObservation(txid);
const comparison = compareTransactionObservations(previousObservation, current);
console.log({ comparison, current });
```

The included `examples/compare-observations.mjs` reads a prior JSON snapshot
when supplied and writes the new observation and comparison to stdout:

```sh
node examples/compare-observations.mjs <txid> > first.json
node examples/compare-observations.mjs <txid> first.json > second.json
```

The comparison checks the canonical input/output outpoints, satoshi amounts,
script hashes and inclusion metadata. It ignores extra indexer annotation
fields. `consistent` means only that those two API observations agree; verify
chain identity, source authenticity and your own finality policy separately.

## Inspect deposit outputs

The 0.1.14 candidate enforces native `u32` output indexes (`0` through
`4294967295`) on receipt inputs and outputs, including offline inspection.

`getDepositTransaction({txid, addressTo, amount})` is the one-call exchange
read path. It validates a checksummed Genesis-4 mainnet deposit address and a
positive decimal BLOCH amount before making a network request, fetches the
complete included receipt, and returns `{transaction, match}`. The `match`
lists the exact output outpoints and integer satoshi total. An archival 404
remains an unresolved lookup error; the function never turns node-local status
into an included receipt.

```js
import { getDepositTransaction } from '@blochprotocol/genesis4-sdk';

const { transaction, match } = await getDepositTransaction({
  txid,
  addressTo: expectedDepositAddress,
  amount: '1.25000000',
});
console.log(transaction.blockId, transaction.height, transaction.finalized);
console.log(match.matchingOutputs, match.matchedAmountSat, match.exactTotal);
```

Run `node examples/query-deposit.mjs <txid> <addressTo> <amount>` for a
read-only mainnet query. This concrete included transaction and output were
checked against Genesis-4 mainnet on 2026-09-23:

```sh
node examples/query-deposit.mjs \
  2a70f41229d8587f060c308279238662c2aa331f4d9f32a660231716f418c672 \
  bloch1q4df3127262d35b22ac2004c297ba60a03625ae9004807572 \
  1992.76963149
```

The result matched output `:0` with `199276963149` satoshis and reported the
transaction at height 84877, slot 113045. This result is an observation, not
a credit decision.

`inspectDepositOutputs({transaction, addressTo, amount})` matches the outputs
of a complete included receipt to a checksummed Genesis-4 mainnet address. It
converts the expected decimal BLOCH amount to integer satoshis, lists every
matching `txid:vout`, sums those amounts with `BigInt`, and returns
`matchedAmountSat`, `differenceSat` and `exactTotal`. It rejects duplicate or
malformed outputs, including values above the unsigned 64-bit limit, and
requires the complete included receipt fields returned by `getTransaction`.
Zero expected amounts are rejected, and `exactTotal` requires at least one
matching output.
The result is a
measurement, not a credit decision; the exchange must apply its own ownership,
finality, duplicate-credit and risk policy. In particular, multiple outputs to
one address are listed separately so each outpoint can be accounted for once.

```js
import { getTransaction, inspectDepositOutputs } from '@blochprotocol/genesis4-sdk';

const transaction = await getTransaction(txid);
const match = inspectDepositOutputs({
  transaction,
  addressTo: expectedDepositAddress,
  amount: '1.25000000',
});
console.log(match.matchingOutputs, match.matchedAmountSat, match.finalized);
```

Run `node examples/inspect-deposit.mjs <txid> <addressTo> <amount>` for a
read-only mainnet query. An archival 404, missing or changed receipt must stay
unresolved; use `getTransactionObservation` and
`compareTransactionObservations` to track that state.

## Verification

`npm test` signs a real transaction through the pinned WASM core against a
synthetic UTXO and tests receipt composition. It does not move mainnet funds.
The lookup example was also run against the live mainnet txid above. No
mainnet signing test can be performed without a funded key supplied by the
exchange; do not send a mnemonic for a production account to the authors.
