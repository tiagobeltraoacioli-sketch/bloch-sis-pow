// SPDX-License-Identifier: AGPL-3.0-or-later
import G4 from './g4.cjs';
import { createCore } from './core.mjs';
import { createHash } from 'node:crypto';

const DEFAULT_RPC = 'https://posternlabs.com/g4rpc';
const DEFAULT_EXPLORER = 'https://blochl1.com';
const HASH = /^[0-9a-f]{64}$/i;
const UINT = /^(0|[1-9][0-9]*)$/;
const MAX_U64 = (1n << 64n) - 1n;
const MAX_U32 = 0xffffffff;
const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 15_000;
const TXID_DOMAIN = Buffer.from('BLCH4:TXID\0\0\0\0\0\0', 'ascii');
class SafeTransportError extends Error {}

function rawCorrelationHash(rawHex) {
  return createHash('sha3-256').update(Buffer.from(rawHex, 'hex')).digest('hex');
}

function txidFromSigningRoot(rootHex) {
  return createHash('sha3-256').update(TXID_DOMAIN).update(Buffer.from(rootHex, 'hex')).digest('hex');
}

// Decode the two transfer wire formats and fold the actual spend fields.
// Mirrors PosTransaction::{from_canonical_bytes,spend_signing_root} in
// crates/bloch-pos-committee/src/transition.rs. This binds identity to bytes;
// it does not verify signatures, UTXO ownership, fees or consensus acceptance.
function signingRootFromTransferBytes(rawHex) {
  const bytes = Buffer.from(rawHex, 'hex');
  let offset = 0;
  const take = length => {
    if (length > bytes.length - offset) throw new Error('Truncated transfer');
    const field = bytes.subarray(offset, offset + length);
    offset += length;
    return field;
  };
  const u32 = () => take(4).readUInt32LE();
  const witness = () => { take(u32()); take(u32()); };
  const count = minimumBytes => {
    const field = take(4);
    const value = field.readUInt32LE();
    if (value > Math.floor((bytes.length - offset) / minimumBytes)) {
      throw new Error('Transfer count exceeds available bytes');
    }
    return { field, value };
  };
  const tag = take(1)[0];
  if (tag !== 0x01 && tag !== 0x06) throw new Error('Unsupported transfer format');
  let keyCount = 0;
  if (tag === 0x06) {
    const keys = count(8);
    keyCount = keys.value;
    for (let i = 0; i < keys.value; i++) witness();
  }
  const hash = createHash('sha3-256').update(Buffer.from('BLCH4:SPEND\0\0\0\0\0', 'ascii'));
  const inputs = count(tag === 0x01 ? 44 : 40);
  hash.update(inputs.field);
  for (let i = 0; i < inputs.value; i++) {
    hash.update(take(36)); // txid and u32 output index
    if (tag === 0x01) witness();
    else if (u32() >= keyCount) throw new Error('Invalid witness-table index');
  }
  const outputs = count(40);
  hash.update(outputs.field);
  for (let i = 0; i < outputs.value; i++) hash.update(take(40));
  hash.update(take(24)); // u64 declared bytes and u128 tip, little-endian
  if (offset !== bytes.length) throw new Error('Trailing transfer bytes');
  return hash.digest('hex');
}

function uint64String(value) {
  return typeof value === 'string' && UINT.test(value) && BigInt(value) <= MAX_U64;
}

function validReceiptEntries(entries, receiptTxid, outputs) {
  if (!Array.isArray(entries)) return false;
  const seen = new Set();
  for (const entry of entries) {
    if (!HASH.test(entry?.txid) || !Number.isSafeInteger(entry.vout) || entry.vout < 0 || entry.vout > MAX_U32 ||
        !HASH.test(entry.script_hash) || !uint64String(entry.value_sat) ||
        (outputs && entry.txid.toLowerCase() !== receiptTxid.toLowerCase())) return false;
    const outpoint = `${entry.txid.toLowerCase()}:${entry.vout}`;
    if (seen.has(outpoint)) return false;
    seen.add(outpoint);
  }
  return true;
}

function validIncludedReceipt(receipt) {
  return receipt && HASH.test(receipt.txid) && HASH.test(receipt.blockId) &&
    validReceiptEntries(receipt.inputs, receipt.txid, false) &&
    validReceiptEntries(receipt.outputs, receipt.txid, true) &&
    [receipt.height, receipt.slot, receipt.transactionIndex, receipt.sizeBytes,
      receipt.confirmations, receipt.finalizedHeight, receipt.observedHeadHeight,
      receipt.observedHeadSlot].every(value => Number.isSafeInteger(value) && value >= 0) &&
    receipt.sizeBytes > 0 && receipt.observedHeadHeight >= receipt.height &&
    receipt.observedHeadSlot >= receipt.slot &&
    receipt.finalizedHeight <= receipt.observedHeadHeight &&
    receipt.confirmations === receipt.observedHeadHeight - receipt.height + 1 &&
    uint64String(receipt.feeSat) && uint64String(receipt.stakeSat) &&
    typeof receipt.kind === 'string' && receipt.kind.length > 0 &&
    typeof receipt.source === 'string' && receipt.source.length > 0 &&
    typeof receipt.verification === 'string' && receipt.verification.length > 0 &&
    ['confirmed', 'finalized'].includes(receipt.status) &&
    receipt.finalized === (receipt.status === 'finalized') &&
    (!receipt.finalized || receipt.finalizedHeight >= receipt.height) &&
    ['corroborated', 'final'].includes(receipt.corroboration);
}

function mainnetAddress(value, name) {
  const info = G4.inspectAddress(value);
  if (!info.verified || info.network !== 'mainnet') {
    throw new Error(`${name}: a checksummed Genesis-4 mainnet address is required (${info.message})`);
  }
  return info;
}

/** Create a fresh Genesis-4 mainnet identity in this Node.js process; no RPC call occurs. */
export function createLocalWallet() {
  const core = createCore();
  try {
    const generated = core.call('new_mnemonic', { words: 24 });
    if (typeof generated?.mnemonic !== 'string' || generated.mnemonic.trim().split(/\s+/).length !== 24) {
      throw new Error('Genesis-4 core did not return a 24-word mnemonic');
    }
    const wallet = core.call('wallet_from_mnemonic', { mnemonic: generated.mnemonic, testnet: false });
    mainnetAddress(wallet?.address, 'generated address');
    return { mnemonic: generated.mnemonic, address: wallet.address, network: 'mainnet' };
  } finally { core.dispose(); }
}

/** Recover the Genesis-4 mainnet address for an existing phrase, entirely locally. */
export function deriveLocalAddress({ mnemonic }) {
  if (typeof mnemonic !== 'string' || !mnemonic.trim()) throw new Error('mnemonic is required');
  const core = createCore();
  try {
    const normalized = core.call('normalize_mnemonic', { mnemonic });
    if (typeof normalized?.mnemonic !== 'string' || !normalized.mnemonic) {
      throw new Error('Genesis-4 core did not normalize the mnemonic');
    }
    const wallet = core.call('wallet_from_mnemonic', { mnemonic: normalized.mnemonic, testnet: false });
    mainnetAddress(wallet?.address, 'derived address');
    return { address: wallet.address, network: 'mainnet' };
  } finally { core.dispose(); }
}

async function json(url, options, fetchImpl, endpoint) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  let response;
  try {
    response = await fetchImpl(url, { ...options, redirect: 'error', signal: controller.signal });
    if (!Number.isInteger(response?.status) || typeof response?.ok !== 'boolean') {
      throw new Error('invalid response');
    }
    // Error bodies are never parsed or reflected in an exception.
    if (!response.ok) {
      const error = new SafeTransportError(`${endpoint}: HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    const claimedLength = Number(response.headers?.get('content-length'));
    if (Number.isFinite(claimedLength) && claimedLength > MAX_RESPONSE_BYTES) {
      void response.body?.cancel().catch(() => {});
      throw new SafeTransportError(`${endpoint}: response exceeds ${MAX_RESPONSE_BYTES} bytes`);
    }
    if (!response.body || typeof response.body.getReader !== 'function') {
      throw new SafeTransportError(`${endpoint}: response body is unavailable`);
    }
    const reader = response.body.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > MAX_RESPONSE_BYTES) throw new SafeTransportError(`${endpoint}: response exceeds ${MAX_RESPONSE_BYTES} bytes`);
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
      if (size > MAX_RESPONSE_BYTES) void response.body.cancel().catch(() => {});
    }
    let body;
    try { body = JSON.parse(Buffer.concat(chunks, size).toString('utf8')); }
    catch { throw new SafeTransportError(`${endpoint}: invalid JSON response`); }
    return body;
  } catch (error) {
    if (error instanceof SafeTransportError) throw error;
    if (controller.signal.aborted) throw new SafeTransportError(`${endpoint}: request timed out`);
    throw new SafeTransportError(`${endpoint}: network request failed`);
  } finally {
    clearTimeout(timer);
  }
}

async function rpc(method, params, rpcUrl, fetchImpl) {
  const attempts = method === 'sendrawtransaction' ? 1 : 3;
  for (let attempt = 0; attempt < attempts; attempt++) {
    const body = await json(rpcUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
    }, fetchImpl, `RPC ${method}`);
    if (!body || typeof body !== 'object' || Array.isArray(body) ||
        body.jsonrpc !== '2.0' || body.id !== 1 ||
        Object.hasOwn(body, 'result') === Object.hasOwn(body, 'error')) {
      throw new Error(`${method}: invalid JSON-RPC response envelope`);
    }
    if (Object.hasOwn(body, 'result')) {
      if (body.result === null) throw new Error(`${method}: missing JSON-RPC result`);
      return body.result;
    }
    if (!body.error || typeof body.error !== 'object' ||
        !Number.isSafeInteger(body.error.code) || typeof body.error.message !== 'string') {
      throw new Error(`${method}: invalid JSON-RPC error`);
    }
    if (![-32051, -32004, -32053].includes(body.error.code) || attempt === attempts - 1) {
      throw new Error(`${method}: RPC error ${body.error.code}`);
    }
    await new Promise(resolve => setTimeout(resolve, 250 * (attempt + 1)));
  }
}

function assertFits(value) {
  const limits = G4.limits;
  const count = (input, name) => {
    if (!/^(0|[1-9][0-9]*)$/.test(String(input ?? ''))) throw new Error(`Core returned invalid ${name}`);
    return BigInt(input);
  };
  if (count(value.declared_tx_bytes, 'declared_tx_bytes') > BigInt(limits.MAX_BLOCK_TX_BYTES) ||
      count(value.gas, 'gas') > BigInt(limits.BLOCK_GAS_LIMIT)) {
    throw new Error('Signed transaction exceeds Genesis-4 consensus limits');
  }
  if (value.raw_hex && (!/^[0-9a-f]+$/i.test(value.raw_hex) || value.raw_hex.length % 2 ||
      value.raw_hex.length / 2 > limits.RPC_MAX_RAW_TX_BYTES)) {
    throw new Error('Signed transaction exceeds the RPC byte limit');
  }
}

async function completeCursorUtxos(scriptHash, rpcUrl, fetchImpl, maxUtxoPages) {
  const all = [];
  let cursor = null;
  let head = null;
  let slot = null;
  let total = null;
  let lastOutpoint = null;
  const seenCursors = new Set();
  for (let pageNumber = 1; pageNumber <= maxUtxoPages; pageNumber++) {
    const page = await rpc('getutxos', [scriptHash, Number(G4.limits.UTXO_PAGE_MAX), cursor], rpcUrl, fetchImpl);
    if (!HASH.test(page?.script_hash) || page.script_hash.toLowerCase() !== scriptHash.toLowerCase() ||
        !HASH.test(page.at_head) || !Number.isSafeInteger(page.at_slot) || page.at_slot < 0 ||
        !Number.isSafeInteger(page.total) || page.total < 0 ||
        !Number.isSafeInteger(page.returned) || !Array.isArray(page.utxos) ||
        page.returned !== page.utxos.length || page.utxos.length > Number(G4.limits.UTXO_PAGE_MAX) ||
        typeof page.truncated !== 'boolean' ||
        (page.truncated ? !/^[0-9a-f]{202}$/i.test(page.next_cursor ?? '') : page.next_cursor !== null)) {
      throw new Error('Node did not return the complete Genesis-4 cursor protocol; no transaction was signed');
    }
    if (head === null) { head = page.at_head.toLowerCase(); slot = page.at_slot; total = page.total; }
    else if (page.at_head.toLowerCase() !== head || page.at_slot !== slot || page.total !== total) {
      throw new Error('UTXO cursor pages changed head, slot or total; no transaction was signed');
    }
    const parsed = G4.parseUtxos(page);
    for (const entry of parsed.utxos) {
      if (!HASH.test(entry.txid) || !HASH.test(entry.scriptHash) ||
          entry.scriptHash.toLowerCase() !== scriptHash.toLowerCase()) {
        throw new Error('UTXO cursor page contained an invalid or foreign output; no transaction was signed');
      }
      const current = { txid: entry.txid.toLowerCase(), vout: entry.vout };
      if (lastOutpoint && (current.txid < lastOutpoint.txid ||
          (current.txid === lastOutpoint.txid && current.vout <= lastOutpoint.vout))) {
        throw new Error('UTXO cursor pages repeated or reordered an outpoint; no transaction was signed');
      }
      lastOutpoint = current;
      all.push(entry);
    }
    if (all.length > total || (page.truncated && (page.utxos.length === 0 || all.length === total))) {
      throw new Error('UTXO cursor page count contradicts the total; no transaction was signed');
    }
    if (!page.truncated) {
      if (all.length !== total) throw new Error('UTXO cursor ended before the reported total; no transaction was signed');
      return { utxos: all, truncated: false, head, slot, pageCount: pageNumber };
    }
    cursor = page.next_cursor.toLowerCase();
    if (cursor.slice(0, 2) !== '01' || cursor.slice(2, 66) !== head ||
        cursor.slice(66, 130) !== scriptHash.toLowerCase() ||
        cursor.slice(130, 194) !== lastOutpoint.txid ||
        Number.parseInt(cursor.slice(194), 16) !== lastOutpoint.vout) {
      throw new Error('UTXO cursor does not bind the last output and chain head; no transaction was signed');
    }
    if (seenCursors.has(cursor)) throw new Error('UTXO cursor repeated; no transaction was signed');
    seenCursors.add(cursor);
  }
  throw new Error(`UTXO cursor exceeded the ${maxUtxoPages}-page safety limit; no transaction was signed`);
}

/** Build a signed Genesis-4 transfer. amount is a decimal BLOCH string. No broadcast occurs. */
export async function createSignedTransaction({
  addressFrom, mnemonic, addressTo, amount, rpcUrl = DEFAULT_RPC, fetchImpl = fetch,
  utxoMode = 'legacy', maxUtxoPages = 10,
}) {
  if (!['legacy', 'cursor'].includes(utxoMode)) throw new Error('utxoMode must be legacy or cursor');
  if (!Number.isSafeInteger(maxUtxoPages) || maxUtxoPages < 1 || maxUtxoPages > 20) {
    throw new Error('maxUtxoPages must be an integer from 1 to 20');
  }
  const from = mainnetAddress(addressFrom, 'addressFrom');
  mainnetAddress(addressTo, 'addressTo');
  const amountSat = G4.sats.toWire(G4.sats.fromUserBLCH(amount));
  if (typeof mnemonic !== 'string' || !mnemonic.trim()) throw new Error('mnemonic is required');
  const core = createCore();
  try {
    const wallet = core.call('wallet_from_mnemonic', { mnemonic, testnet: false });
    if (String(wallet.address).toLowerCase() !== addressFrom.trim().toLowerCase()) {
      throw new Error('addressFrom does not match the mnemonic');
    }
    let utxos, chainResult;
    if (utxoMode === 'cursor') {
      utxos = await completeCursorUtxos(from.scriptHash, rpcUrl, fetchImpl, maxUtxoPages);
      chainResult = await rpc('getchaininfo', [], rpcUrl, fetchImpl);
      if (!HASH.test(chainResult?.block_id) || chainResult.block_id.toLowerCase() !== utxos.head ||
          chainResult.slot !== utxos.slot) {
        throw new Error('Chain head changed after UTXO enumeration; no transaction was signed');
      }
    } else {
      const [utxoResult, currentChain] = await Promise.all([
        rpc('getutxos', [from.scriptHash, Number(G4.limits.UTXO_PAGE_MAX)], rpcUrl, fetchImpl),
        rpc('getchaininfo', [], rpcUrl, fetchImpl),
      ]);
      utxos = G4.parseUtxos(utxoResult);
      chainResult = currentChain;
    }
    const chain = G4.parseChainInfo(chainResult);
    if (!Number.isSafeInteger(chain.epoch) || chain.nextBaseFeeMillisatPerGas == null ||
        chain.slot == null || !Number.isSafeInteger(chainResult.behind_by_slots) || chainResult.behind_by_slots > 2) {
      throw new Error('Current Genesis-4 epoch, next base fee, or fresh chain head is unavailable');
    }
    const args = {
      mnemonic, to: addressTo, testnet: false,
      amount_sats: amountSat,
      base_fee_millisat_per_gas: chain.nextBaseFeeMillisatPerGas.toString(),
      epoch: String(chain.epoch),
      utxos: G4.toSignerUtxos(utxos),
    };
    const preview = core.call('g4_transfer_preview', args);
    assertFits(preview);
    let signed;
    for (let attempt = 0; attempt < 5; attempt++) {
      try { signed = core.call('g4_build_and_sign_transfer', args); break; }
      catch (error) {
        if (!/assumed ceiling|but declares/i.test(String(error.message)) || attempt === 4) throw error;
      }
    }
    assertFits(signed);
    if (!HASH.test(signed.txid_hex) || !HASH.test(signed.signing_root_hex) ||
        signed.txid_hex !== preview.txid_hex || signed.signing_root_hex !== preview.signing_root_hex ||
        signed.amount_sats !== amountSat || !signed.raw_hex) {
      throw new Error('Signed transaction differs from its preview');
    }
    if (txidFromSigningRoot(signed.signing_root_hex) !== signed.txid_hex) {
      throw new Error('Signed transaction ID differs from its domain-separated signing root');
    }
    const envelope = {
      txid: signed.txid_hex,
      rawHex: signed.raw_hex,
      signingRootHex: signed.signing_root_hex,
      rawHash: rawCorrelationHash(signed.raw_hex),
      amountSat,
      feeSat: signed.fee_sats,
      inputCount: signed.input_count,
      outputCount: signed.output_count,
      epoch: chain.epoch,
      baseFeeMillisatPerGas: args.base_fee_millisat_per_gas,
      format: signed.format,
      selectedUtxos: signed.selected_utxos,
      utxosTruncated: utxos.truncated,
      utxoMode,
      utxoPageCount: utxos.pageCount ?? 1,
      utxoSourceHead: utxos.head ?? null,
    };
    verifySignedEnvelope(envelope);
    return envelope;
  } finally { core.dispose(); }
}

/** Check the persisted SDK envelope before any transaction network request. */
function verifySignedEnvelope(input) {
  // Capture each field once: callers may mutate their object while a request
  // is pending. All checks, submission and returned identity use this snapshot.
  const signed = { txid: input?.txid, signingRootHex: input?.signingRootHex,
    rawHash: input?.rawHash, rawHex: input?.rawHex };
  if (Object.values(signed).some(value => typeof value !== 'string')) {
    throw new Error('SDK signed transaction identity fields must be strings');
  }
  if (!HASH.test(signed?.txid) || !HASH.test(signed?.signingRootHex) || !HASH.test(signed?.rawHash) ||
      signed.rawHex.length / 2 > G4.limits.RPC_MAX_RAW_TX_BYTES ||
      signed.rawHex.length % 2 || !/^[0-9a-f]+$/i.test(signed.rawHex)) {
    throw new Error('A complete SDK signed transaction with txid, signingRootHex, rawHash and rawHex is required');
  }
  if (txidFromSigningRoot(signed.signingRootHex) !== signed.txid.toLowerCase() ||
      rawCorrelationHash(signed.rawHex) !== signed.rawHash.toLowerCase()) {
    throw new Error('Signed transaction identity or bytes changed; nothing was submitted');
  }
  try {
    if (signingRootFromTransferBytes(signed.rawHex) !== signed.signingRootHex.toLowerCase()) {
      throw new Error('Spend root mismatch');
    }
  } catch {
    throw new Error('Signed transaction bytes do not encode the declared transfer identity; nothing was submitted');
  }
  return Object.freeze({ ...signed, txid: signed.txid.toLowerCase(),
    signingRootHex: signed.signingRootHex.toLowerCase(), rawHash: signed.rawHash.toLowerCase() });
}

/** Broadcast bytes created above. The returned tx_hash is not the consensus txid. */
export async function broadcastSignedTransaction(signed, { rpcUrl = DEFAULT_RPC, fetchImpl = fetch } = {}) {
  const envelope = verifySignedEnvelope(signed);
  const admission = await rpc('sendrawtransaction', [envelope.rawHex], rpcUrl, fetchImpl);
  if (admission?.accepted !== true) {
    throw new Error('sendrawtransaction did not confirm mempool admission; check the txid before building another transfer');
  }
  if (admission.tx_hash?.toLowerCase() !== envelope.rawHash ||
      admission.bytes !== envelope.rawHex.length / 2) {
    throw new Error('Node reported admission with mismatched byte count or correlation hash; check the original txid before any retry');
  }
  return { txid: envelope.txid, admission };
}

/** Return an indexed canonical receipt with confirmation and finality status. */
export async function getTransaction(txid, { explorerUrl = DEFAULT_EXPLORER, fetchImpl = fetch } = {}) {
  if (!HASH.test(txid)) throw new Error('txid must be 64 hexadecimal characters');
  const base = explorerUrl.replace(/\/$/, '');
  const receipt = await json(`${base}/api/v1/transactions/${txid.toLowerCase()}`, { method: 'GET' }, fetchImpl, 'Archival transaction');
  if (!HASH.test(receipt.txid) || receipt.txid.toLowerCase() !== txid.toLowerCase() ||
      !HASH.test(receipt.block_id) ||
      !validReceiptEntries(receipt.inputs, receipt.txid, false) ||
      !validReceiptEntries(receipt.outputs, receipt.txid, true) ||
      ![receipt.height, receipt.slot, receipt.index, receipt.size_bytes,
        receipt.confirmations, receipt.finalized_height, receipt.observed_head_height,
        receipt.observed_head_slot].every(value => Number.isSafeInteger(value) && value >= 0) ||
      receipt.size_bytes === 0 || receipt.observed_head_height < receipt.height ||
      receipt.observed_head_slot < receipt.slot ||
      receipt.finalized_height > receipt.observed_head_height ||
      receipt.confirmations !== receipt.observed_head_height - receipt.height + 1 ||
      !uint64String(receipt.fee_sat) || !uint64String(receipt.stake_sat) ||
      typeof receipt.kind !== 'string' || !receipt.kind ||
      typeof receipt.source !== 'string' || !receipt.source ||
      typeof receipt.verification !== 'string' || !receipt.verification ||
      !['confirmed', 'finalized'].includes(receipt.status) ||
      receipt.finalized !== (receipt.status === 'finalized') ||
      (receipt.finalized && receipt.finalized_height < receipt.height) ||
      !['corroborated', 'final'].includes(receipt.corroboration)) {
    throw new Error('Indexer returned an incomplete or mismatched transaction receipt');
  }
  return {
    txid: receipt.txid,
    blockId: receipt.block_id,
    height: receipt.height,
    slot: receipt.slot,
    transactionIndex: receipt.index,
    kind: receipt.kind,
    inputs: receipt.inputs,
    outputs: receipt.outputs,
    feeSat: receipt.fee_sat,
    stakeSat: receipt.stake_sat,
    sizeBytes: receipt.size_bytes,
    confirmations: receipt.confirmations,
    status: receipt.status,
    finalized: receipt.finalized,
    finalizedHeight: receipt.finalized_height,
    observedHeadHeight: receipt.observed_head_height,
    observedHeadSlot: receipt.observed_head_slot,
    corroboration: receipt.corroboration,
    source: receipt.source,
    verification: receipt.verification,
  };
}

/** Reconcile an included receipt or report a single node's unresolved observation. */
export async function getTransactionObservation(txid, {
  explorerUrl = DEFAULT_EXPLORER, rpcUrl = DEFAULT_RPC, fetchImpl = fetch,
} = {}) {
  if (!HASH.test(txid)) throw new Error('txid must be 64 hexadecimal characters');
  try {
    const receipt = await getTransaction(txid, { explorerUrl, fetchImpl });
    return { kind: 'included', txid: receipt.txid, receipt };
  } catch (error) {
    if (error.status !== 404) throw error;
  }
  try {
    const result = await rpc('gettxstatus', [txid.toLowerCase()], rpcUrl, fetchImpl);
    const status = result?.status;
    if (!['pending', 'included', 'justified', 'finalized', 'unknown'].includes(status)) {
      throw new Error('gettxstatus returned an invalid node status');
    }
    return {
      kind: 'unresolved', txid: txid.toLowerCase(), nodeStatus: status,
      source: 'single-node gettxstatus',
      note: 'No canonical archival receipt was found. Node status cannot establish deposit credit, finality, absence or failure.',
    };
  } catch (error) {
    return {
      kind: 'unresolved', txid: txid.toLowerCase(), nodeStatus: null,
      source: 'archival 404; node status unavailable',
      note: 'No canonical archival receipt or usable node observation was available. Do not infer transaction failure.',
      observationError: error.message,
    };
  }
}

/** Observe a stored signed transfer after submission or an ambiguous timeout. No rebroadcast occurs. */
export async function trackSignedTransaction(signed, {
  previousObservation = null, explorerUrl = DEFAULT_EXPLORER,
  rpcUrl = DEFAULT_RPC, fetchImpl = fetch,
} = {}) {
  const { txid } = verifySignedEnvelope(signed);
  const observation = await getTransactionObservation(txid, { explorerUrl, rpcUrl, fetchImpl });
  const comparison = compareTransactionObservations(previousObservation, observation);
  return { txid, observation, comparison };
}

/** Compare saved observations without deciding an exchange's credit or payout policy. */
export function compareTransactionObservations(previous, current) {
  const valid = item => item && HASH.test(item.txid) &&
    (item.kind === 'unresolved' || (item.kind === 'included' &&
      validIncludedReceipt(item.receipt) &&
      item.receipt.txid.toLowerCase() === item.txid.toLowerCase()));
  if (!valid(current) || (previous != null && !valid(previous))) {
    throw new Error('Valid transaction observations are required');
  }
  if (previous && previous.txid.toLowerCase() !== current.txid.toLowerCase()) {
    throw new Error('Cannot compare different transaction IDs');
  }
  const result = (status, requiresReview, detail) => ({
    txid: current.txid.toLowerCase(), status, requiresReview, detail,
  });
  if (current.kind === 'unresolved') {
    return previous?.kind === 'included'
      ? result('receipt_unavailable', true, 'A previously included receipt is unavailable. Check the index and chain independently; do not infer a reorg or failure from this alone.')
      : result('unresolved', true, 'Only a node-local status or no status is available; there is no included archival receipt.');
  }
  if (previous?.kind !== 'included') {
    return result('first_inclusion', true, 'An included receipt is now available. Apply your own amount, destination, confirmation and finality checks.');
  }
  const before = previous.receipt, after = current.receipt;
  if (before.blockId.toLowerCase() !== after.blockId.toLowerCase() ||
      before.height !== after.height || before.slot !== after.slot) {
    return result('block_changed', true, 'The recorded inclusion moved to a different block, height or slot. Review chain history and the stored credit decision.');
  }
  const transfers = receipt => [receipt.inputs, receipt.outputs].map(entries =>
    entries.map(({ txid, vout, value_sat, script_hash }) => [txid, vout, value_sat, script_hash]));
  if (JSON.stringify([transfers(before), before.feeSat, before.stakeSat]) !==
      JSON.stringify([transfers(after), after.feeSat, after.stakeSat])) {
    return result('receipt_changed', true, 'The indexed transaction contents changed for the same txid and block. Review the source records.');
  }
  if (before.transactionIndex !== after.transactionIndex || before.kind !== after.kind ||
      before.sizeBytes !== after.sizeBytes) {
    return result('receipt_changed', true, 'The indexed transaction metadata changed for the same txid and block. Review the source records.');
  }
  if ((before.finalized && !after.finalized) ||
      after.finalizedHeight < before.finalizedHeight ||
      (before.corroboration === 'final' && after.corroboration !== 'final')) {
    return result('finality_regressed', true, 'The reported finality or corroboration regressed. Compare independent nodes and checkpoints.');
  }
  if (after.confirmations < before.confirmations || after.observedHeadHeight < before.observedHeadHeight ||
      after.observedHeadSlot < before.observedHeadSlot) {
    return result('head_regressed', true, 'The reported head, slot or confirmation count moved backward. Check for stale data or a chain reorganization.');
  }
  return result('consistent', false, 'The stored inclusion and reported progress are consistent across these two observations; this is not independent settlement proof.');
}

/** Match canonical receipt outputs to an expected mainnet address and decimal BLOCH amount. */
export function inspectDepositOutputs({ transaction, addressTo, amount }) {
  const target = mainnetAddress(addressTo, 'addressTo');
  const expectedAmountSat = G4.sats.toWire(G4.sats.fromUserBLCH(amount));
  if (BigInt(expectedAmountSat) === 0n) throw new Error('Deposit amount must be greater than zero');
  // Validate the receipt envelope first so malformed outputs retain a specific error.
  if (!validIncludedReceipt(transaction && { ...transaction, outputs: [] })) {
    throw new Error('A complete included transaction receipt is required');
  }
  const seen = new Set();
  const matchingOutputs = [];
  for (const output of transaction.outputs) {
    if (!HASH.test(output?.txid) || output.txid.toLowerCase() !== transaction.txid.toLowerCase() ||
        !Number.isSafeInteger(output.vout) || output.vout < 0 || output.vout > MAX_U32 ||
        !HASH.test(output.script_hash) ||
        !uint64String(output.value_sat) ||
        seen.has(output.vout)) {
      throw new Error('Receipt contains an invalid or duplicate output');
    }
    seen.add(output.vout);
    if (output.script_hash.toLowerCase() === target.scriptHash.toLowerCase()) {
      matchingOutputs.push({ txid: transaction.txid, vout: output.vout, valueSat: output.value_sat });
    }
  }
  const matchedAmountSat = matchingOutputs.reduce((total, output) => total + BigInt(output.valueSat), 0n);
  const expected = BigInt(expectedAmountSat);
  return {
    txid: transaction.txid, blockId: transaction.blockId,
    height: transaction.height, slot: transaction.slot,
    confirmations: transaction.confirmations, finalized: transaction.finalized,
    address: addressTo, scriptHash: target.scriptHash,
    expectedAmountSat, matchedAmountSat: matchedAmountSat.toString(),
    differenceSat: (matchedAmountSat - expected).toString(),
    exactTotal: matchingOutputs.length > 0 && matchedAmountSat === expected,
    matchingOutputs,
    note: 'Output matching is a receipt inspection, not a deposit credit decision. Apply your own finality, ownership and duplicate-credit policy.',
  };
}

/** Query and inspect one included deposit without requiring exchange-side receipt plumbing. */
export async function getDepositTransaction({
  txid, addressTo, amount, explorerUrl = DEFAULT_EXPLORER, fetchImpl = fetch,
}) {
  mainnetAddress(addressTo, 'addressTo');
  const expectedAmountSat = G4.sats.fromUserBLCH(amount);
  if (expectedAmountSat === 0n) throw new Error('Deposit amount must be greater than zero');
  const transaction = await getTransaction(txid, { explorerUrl, fetchImpl });
  const match = inspectDepositOutputs({ transaction, addressTo, amount });
  return { transaction, match };
}
